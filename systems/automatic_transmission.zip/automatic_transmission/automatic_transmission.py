import os
import matlab.engine
import numpy as np


class AutomaticTransmission:

    def __init__(self):

        self.brake_cmd_seq = []
        self.throttle_cmd_seq = []
        'Starting Matlab engine'
        self.eng = matlab.engine.start_matlab()
        path = os.path.dirname(os.getcwd()) + '/systems/automatic_transmission/ARCH2019'
        self.eng.cd(path, nargout=0)


    def step(self, state, cmd_args):

        dt = 0.01
        brake = float(cmd_args[0])
        throttle = float(cmd_args[1])
        self.brake_cmd_seq.append(brake)
        self.throttle_cmd_seq.append(throttle)
        trace_len = len( self.brake_cmd_seq)
        time_steps = np.linspace(0, dt * trace_len, num=trace_len).tolist()

        states = self.eng.test(self.throttle_cmd_seq, self.brake_cmd_seq, time_steps, trace_len * dt)

        return  list(states[-1])


def pre_processing():
    return AutomaticTransmission()

