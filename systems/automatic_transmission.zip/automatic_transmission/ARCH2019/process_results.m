function out = process_results(results, outputfile, model, init_cond, input_range, cp_array, simTime,opt) %, iteration)
% This function reads the intermediate state information from staliro
% generated file and reruns the simulink model with these data to produce
% the actual output states for coverage evaluation.

% intermediate_results = load(staliro_result_file);
% samples = intermediate_results.intermediateStaliroResults.history.samples;

samples = [results.run.bestSample]';
% last_sample = size(samples, 1);
% all_trajectories = [];
all_trajectories = {};
for i = 1:size(samples, 1)
    XPoint = [];
    UPoint = samples(i,:);
    out = [0.0 0.0 0.0];
    %UPoint = samples(last_sample,:); % get the last sample instead of looping over all of them
    model1= staliro_blackbox(model);
    [hs,~,inpSig] = systemsimulator(model1, XPoint, UPoint, simTime, input_range, cp_array, opt);
    T1=hs.T;
    YT1=hs.YT; % speed, RPM
    LT1=hs.LT; % gear
    tmp_ = [YT1 LT1]; % for some reason that I could not identifiy it is a 1000*3 array; no matter what the timestamp size is
    tmp = tmp_(1:100, :); % get first 100 steps
    out = [out;tmp];
%     all_trajectories = [all_trajectories;  out]; 
    all_trajectories{end+1} = out; 
end

% save(output_file, 'out');
% Convert the cell array to a JSON-compatible structure
size(all_trajectories)
json_data = jsonencode(all_trajectories);

% Write the JSON data to a file
fid = fopen(outputfile, 'w');
fprintf(fid, '%s', json_data);
fclose(fid);


% falsified = [results.run.falsified]';
% falsified_count = 0;
% first_falsified_run = 0;
% 
% for i = 1:size(falsified, 1)
%     if falsified(i,1) == 1
%         falsified_count = falsified_count + 1;
%         if first_falsified_run == 0
%             first_falsified_run = i;
%         end
%     end
% end
% 
% fprintf('\n Round %d : falsified_count %d, first_falsified_run %d \n', iteration, falsified_count, first_falsified_run)

end

