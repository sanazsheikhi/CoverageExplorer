clear
% speed->1 RPM->2 gear->3

phi_ind = 2;
trans_pred_phi;

opt = staliro_options();
opt.optimization_solver = 'SOAR_Taliro_LocalGPs';
opt.SampTime = 0.05; %Sanaz
opt.runs = 100;
opt.spec_space = 'Y';
opt.optim_params.n_tests = 100; %ntest will specifies the rest of tests
% opt.seed= 131013014;%randi([1 2147483647]);   
cp_array = [7,3];
opt.loc_traj = 'end';
% opt.taliro_metric = 'hybrid_inf';
opt.black_box = 1;
% opt.save_intermediate_results = 1;
% opt.save_intermediate_results_varname = 'Staliro_results_SOAR_s3';

phi_ = phi{phi_ind};

if phi_ind> 2 && phi_ind <7
   opt.taliro_metric = 'hybrid_inf';
end

% This line of code is so important for the optimization solver %
opt.interpolationtype = {'pconst','pconst'};

init_cond = [];

input_range = [0 100;0 350];
model = @blackbox_autotrans;
tf = 30;
warning off %#ok<*WNOFF>

for c=1:10
    fprintf('Round %d', c)
    opt.seed= randi([1 2147483647]);
    outputfile = 'Staliro_states_SOAR_s2_' + string(opt.seed);
    [results,history] = staliro(model,init_cond,input_range,cp_array,phi_,preds,tf,opt);

    process_results(results, outputfile, model, init_cond, input_range, cp_array, tf, opt, c) %Sanaz
end

% save('SOAR_Trans_s3_Arch19Bench','results','history')

% Start: Sanaz
% intermediate_results = load("xxxx.mat");
% samples = intermediate_results.intermediateStaliroResults.history.samples;
% 
% if results.run(results.optRobIndex).falsified
%     XPoint = [];
%     UPoint = results.run(results.optRobIndex).bestSample
%     simTime = 30;
%     model1= staliro_blackbox(model);
%     [hs,~,inpSig] = systemsimulator(model1, XPoint, UPoint, simTime, input_range, cp_array, opt);
%     T1=hs.T;
%     YT1=hs.YT; % speed, RPM
%     LT1=hs.LT; % gear
% 
%     out = [YT1 LT1];
%     save('yyyy.mat', 'out');
%     out = [YT1 LT1];
%     save('yyyy.mat', 'out');
% else
%     disp('no falsification')
% end


% End: Sanaz

