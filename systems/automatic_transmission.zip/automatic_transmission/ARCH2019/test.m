function  out = test(throttle, brake, timesteps, simTime)
% function  YTtmp = test()

    tm1 = cell2mat(throttle);
    tm2 = cell2mat(brake);
    tm3 = [tm1;tm2];
    tm4 = transpose(tm3);
    simT = simTime;
    t = transpose(cell2mat(timesteps));
    simopt = simget('Autotrans_shift');
    simopt = simset(simopt,'SaveFormat','Array'); % Replace input outputs with structures
    [T, XT, YTtmp] = sim('Autotrans_shift',[0 simT],simopt,[t tm4]);

    out = YTtmp;

%     rng(0,'twister');
%     bmin = 0;
%     bmax = 500;
%     b1 = (bmax-bmin).*rand(20,1) + bmin;
%     tmin = 0;
%     tmax = 100;
%     t1 = (tmax-tmin).*rand(20,1) + tmin;
%     u = [t1 b1]
% 
%     time = [];
%     t=0;
%     for i=1:20
%         time = [time; {t}];
%         t = t + 0.05;
%     end
%    time = cell2mat(time)
% 
%    whos u
%    whos time
% 
%     simT = 30;
%     simopt = simget('autotrans_mod04');
%     simopt = simset(simopt,'SaveFormat','Array'); % Replace input outputs with structures
%     [T, XT, YTtmp] = sim('autotrans_mod04',[0 simT],simopt,[time u]);
%     
%     whos YTtmp
%     whos XT
%     out = YTtmp(:,1:2);
end