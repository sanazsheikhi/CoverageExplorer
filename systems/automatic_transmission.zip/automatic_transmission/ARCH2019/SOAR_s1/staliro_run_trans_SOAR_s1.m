clear
% speed->1 RPM->2 gear->3

phi_ind = 1;
trans_pred_phi;

opt = staliro_options();
opt.optimization_solver = 'SOAR_Taliro_LocalGPs';
opt.SampTime = 0.05; %Sanaz
opt.runs = 100 ;
opt.spec_space = 'Y';
opt.optim_params.n_tests = 100; %ntest will specifies the rest of tests
% opt.seed= 131013014;%randi([1 2147483647]);   
cp_array = [7,3];
opt.loc_traj = 'end';
% opt.taliro_metric = 'hybrid_inf';
opt.black_box = 1;
% opt.save_intermediate_results = 1;
% opt.save_intermediate_results_varname = 'Staliro_results_SOAR_s3';

phi_ = phi{phi_ind};

opt.optimization_solver = 'SA_Taliro';

if phi_ind> 2 && phi_ind <7
   opt.taliro_metric = 'hybrid_inf';
end

%This line of code is so important for the optimization solver 
opt.interpolationtype = {'pconst','pconst'};



init_cond = [];

input_range = [0 100;0 350];
model = @blackbox_autotrans;
tf = 30;
warning off %#ok<*WNOFF>

for c=1:10
    fprintf('Round %d', c)
    opt.seed= randi([1 2147483647]);
    outputfile = 'Staliro_states_SOAR_s1_' + string(opt.seed);
    [results,history] = staliro(model,init_cond,input_range,cp_array,phi_,preds,tf,opt);

    process_results(results, outputfile, model, init_cond, input_range, cp_array, tf, opt, c) %Sanaz
    
end

% save('SOAR_Trans_s3_Arch19Bench','results','history')


% End: Sanaz

