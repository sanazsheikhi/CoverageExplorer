clear
% speed->1 RPM->2 gear->3

phi_ind = 5;
trans_pred_phi;

opt = staliro_options();
opt.optimization_solver = 'SOAR_Taliro_LocalGPs';
% opt.SampTime = 0.05; %Sanaz : but it seems it does not have effect
opt.runs = 50;
opt.spec_space = 'Y';
opt.optim_params.n_tests = 100; %ntest will specifies the rest of tests
% opt.seed= 131013014;%randi([1 2147483647]);   
cp_array = [7,3];
opt.loc_traj = 'end';
% opt.taliro_metric = 'hybrid_inf';
opt.black_box = 1;
phi_ = phi{phi_ind};
if phi_ind> 2 && phi_ind <7
   opt.taliro_metric = 'hybrid_inf';
end
init_cond = [];

input_range = [0 100;0 350]; %[thorttle, brake]
model = @blackbox_autotrans;
tf = 10;%30; to be consistent with MPC runtime
warning off %#ok<*WNOFF>

[results,history] = staliro(model,init_cond,input_range,cp_array,phi_,preds,tf,opt);
% save('SOAR_Trans_s5_Arch19Bench','results','history')

for c=1:5
    fprintf('Round %d', c)
    opt.seed= randi([1 2147483647]);
    outputfile = 'Staliro_states_SOAR_s5_' + string(opt.seed);
    [results,history] = staliro(model,init_cond,input_range,cp_array,phi_,preds,tf,opt);

    process_results(results, outputfile, model, init_cond, input_range, cp_array, tf, opt, c) %Sanaz
    
end

