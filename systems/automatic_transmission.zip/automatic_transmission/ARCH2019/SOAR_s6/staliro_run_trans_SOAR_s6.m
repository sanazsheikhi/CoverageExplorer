% function out = run_automatic_transmission(sim_count, steps, dt_) %, iteration)
function out = run_automatic_transmission() 

clear
% speed->1 RPM->2 gear->3

phi_ind = 6;
trans_pred_phi;
iteration = 10;

for j=1:iteration
    opt = staliro_options();
    % opt.taliro = 'dp_t_taliro';
    opt.optimization_solver = 'SOAR_Taliro_LocalGPs';
    opt.SampTime = 0.01; % sample time interval;
    opt.runs = 100;%sim_count; % The number of times it tries to find the best samples
    opt.spec_space = 'Y';
    opt.optim_params.n_tests = 100; %ntest will specifies the rest of tests
    % opt.seed= 131013014;%randi([1 2147483647]);   
    cp_array = [7,3];
    opt.loc_traj = 'end';
    % opt.taliro_metric = 'hybrid_inf';
    opt.black_box = 1;
    phi_ = phi{phi_ind};
    if phi_ind> 2 && phi_ind <7
       opt.taliro_metric = 'hybrid_inf';
    end
    init_cond = [];
    
    input_range = [0 100;0 350];
    model = @blackbox_autotrans;
    tf = 10; %30; % consistency with MPC; it needs to be at least 10; o.w. it crashes
    warning off %#ok<*WNOFF>
    
    %[results,history] = staliro(model,init_cond,input_range,cp_array,phi_,preds,tf,opt);
    % save('SOAR_Trans_s6_Arch19Bench','results','history')
    
    
    all_trajectories = [];
    outputfile = '/home/sanaz/Documents/Projects/CoverageGuidedExplorer/utility/results/automatic_transmission_S6_staliro_' + string(j)+ '.json';
    

    % for c=1:3
    opt.seed= randi([1 2147483647]);
    % outputfile = '/home/sanaz/Documents/Projects/CoverageGuidedExplorer/utility/results/Staliro_states_SOAR_s6_' + string(opt.seed);
    [results,history] = staliro(model,init_cond,input_range,cp_array,phi_, preds, tf, opt);
    out = process_results(results, outputfile, model, init_cond, input_range, cp_array, tf, opt);
    % all_trajectories = [all_trajectories;  out]; % !!!!: it is important to use ';' than ',' for concat. to have vertical concat
    % end

end




